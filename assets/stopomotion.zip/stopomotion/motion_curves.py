import bpy

from .stop_action import iter_action_fcurves


def get_channel_type(data_path):
    """Determina si el data_path corresponde a Loc, Rot, o Scl."""
    dp_lower = data_path.lower()
    if "location" in dp_lower:
        return "LOC"
    elif ("rotation_euler" in dp_lower or
          "rotation_quaternion" in dp_lower or
          "rotation_axis_angle" in dp_lower):
        return "ROT"
    elif "scale" in dp_lower:
        return "SCL"
    return None


class SMQ_OT_SetConstantInterpolation(bpy.types.Operator):
    bl_idname = "smq.set_constant_interpolation"
    bl_label = "Set Constant Interpolation"
    bl_description = "Set interpolation to CONSTANT for selected keyframes"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data found.")
            return {'CANCELLED'}

        modified_count = 0
        for fc in iter_action_fcurves(obj):
            for kp in fc.keyframe_points:
                if kp.select_control_point and kp.interpolation != 'CONSTANT':
                    kp.interpolation = 'CONSTANT'
                    modified_count += 1

        if modified_count > 0:
            self.report({'INFO'}, f"Set {modified_count} keyframes to CONSTANT.")
        else:
            self.report({'INFO'}, "No keyframes changed (already CONSTANT or none selected).")

        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class SMQ_OT_RevertToBezierInterpolation(bpy.types.Operator):
    bl_idname = "smq.revert_to_bezier"
    bl_label = "Revert to Bezier"
    bl_description = "Set interpolation to BEZIER for selected keyframes or all if none selected"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data found.")
            return {'CANCELLED'}

        fcurves = list(iter_action_fcurves(obj))
        any_selected = any(kp.select_control_point for fc in fcurves for kp in fc.keyframe_points)

        modified_count = 0
        for fc in fcurves:
            for kp in fc.keyframe_points:
                target = (kp.select_control_point if any_selected else True)
                if target and kp.interpolation != 'BEZIER':
                    kp.interpolation = 'BEZIER'
                    modified_count += 1

        if modified_count > 0:
            self.report({'INFO'}, f"Set {modified_count} keyframes to BEZIER.")
        else:
            self.report({'INFO'}, "No keyframes changed (already BEZIER or criteria not met).")

        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class SMQ_OT_AddSteppedFCurveModifier(bpy.types.Operator):
    bl_idname = "smq.add_fcurve_stepped_modifier"
    bl_label = "Add Stepped Modifier to F-Curves"
    bl_description = "Add STEPPED modifier to selected keyframes' F-Curves using current panel settings"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        scene = context.scene

        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data on the active object")
            return {'CANCELLED'}

        frame_step_value = 2 if scene.smq_quant_mode == 'TWOS' else 3

        added = 0
        for fc in iter_action_fcurves(obj):
            if not any(kp.select_control_point for kp in fc.keyframe_points):
                continue

            if any(mod.type == 'STEPPED' for mod in fc.modifiers):
                continue

            mod = fc.modifiers.new(type='STEPPED')
            mod.frame_step = frame_step_value
            mod.use_influence = True
            mod.influence = scene.smq_influence
            mod.use_restricted_range = scene.smq_use_frame_range
            mod.frame_start = scene.smq_frame_start
            mod.frame_end = scene.smq_frame_end
            mod.blend_in = scene.smq_blend_in
            mod.blend_out = scene.smq_blend_out
            added += 1

        self.report({'INFO'}, f"{added} new STEPPED modifier(s) added." if added else "No new STEPPED modifiers added.")
        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class SMQ_OT_RemoveSteppedFCurveModifiers(bpy.types.Operator):
    bl_idname = "smq.remove_fcurve_stepped_modifiers"
    bl_label = "Remove Stepped Modifiers"
    bl_description = "Remove all STEPPED modifiers from selected F-Curves"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data on the active object")
            return {'CANCELLED'}

        removed = 0
        for fc in iter_action_fcurves(obj):
            if not any(kp.select_control_point for kp in fc.keyframe_points):
                continue
            for mod in fc.modifiers[:]:
                if mod.type == 'STEPPED':
                    fc.modifiers.remove(mod)
                    removed += 1

        self.report({'INFO'}, f"{removed} STEPPED modifiers removed.")
        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class SMQ_OT_UpdateSteppedModifier(bpy.types.Operator):
    bl_idname = "smq.update_stepped_modifier"
    bl_label = "Update Stepped Modifier"
    bl_description = "Update parameters of the STEPPED F-Curve modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        obj = context.object

        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data on the active object")
            return {'CANCELLED'}

        frame_step_value = 2 if scene.smq_quant_mode == 'TWOS' else 3

        updated = 0
        for fc in iter_action_fcurves(obj):
            if not any(kp.select_control_point for kp in fc.keyframe_points):
                continue
            for mod in fc.modifiers:
                if mod.type == 'STEPPED':
                    mod.frame_step = frame_step_value
                    mod.use_restricted_range = scene.smq_use_frame_range
                    mod.frame_start = scene.smq_frame_start
                    mod.frame_end = scene.smq_frame_end
                    mod.blend_in = scene.smq_blend_in
                    mod.blend_out = scene.smq_blend_out
                    mod.influence = scene.smq_influence
                    updated += 1
                    break

        self.report({'INFO'}, f"{updated} STEPPED modifier(s) updated." if updated else "No STEPPED modifiers found to update.")
        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class SMQ_OT_AddNoiseModifier(bpy.types.Operator):
    bl_idname = "smq.add_noise_modifier"
    bl_label = "Add Noise Modifier"
    bl_description = "Add NOISE modifier to F-Curves matching active Loc/Rot/Scl toggles"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        scene = context.scene

        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data found.")
            return {'CANCELLED'}

        added = 0
        for fc in iter_action_fcurves(obj):
            if not any(kp.select_control_point for kp in fc.keyframe_points):
                continue

            channel_type = get_channel_type(fc.data_path)
            apply = (
                (channel_type == "LOC" and scene.smq_noise_apply_loc) or
                (channel_type == "ROT" and scene.smq_noise_apply_rot) or
                (channel_type == "SCL" and scene.smq_noise_apply_scl)
            )
            if not apply:
                continue

            if any(mod.type == 'NOISE' for mod in fc.modifiers):
                continue

            mod = fc.modifiers.new(type='NOISE')
            mod.scale = scene.smq_noise_scale
            mod.strength = scene.smq_noise_strength
            mod.depth = scene.smq_noise_depth
            mod.use_influence = True
            mod.influence = scene.smq_noise_influence
            mod.use_restricted_range = scene.smq_noise_use_frame_range
            mod.frame_start = scene.smq_noise_frame_start
            mod.frame_end = scene.smq_noise_frame_end
            mod.blend_in = scene.smq_noise_blend_in
            mod.blend_out = scene.smq_noise_blend_out
            added += 1

        self.report({'INFO'}, f"{added} new NOISE modifier(s) added." if added else "No new NOISE modifiers added.")
        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class SMQ_OT_RemoveNoiseModifier(bpy.types.Operator):
    bl_idname = "smq.remove_noise_modifier"
    bl_label = "Remove Noise Modifier"
    bl_description = "Remove ALL Noise modifiers from F-Curves with selected keyframes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data found.")
            return {'CANCELLED'}

        removed = 0
        for fc in iter_action_fcurves(obj):
            if not any(kp.select_control_point for kp in fc.keyframe_points):
                continue
            for mod in fc.modifiers[:]:
                if mod.type == 'NOISE':
                    fc.modifiers.remove(mod)
                    removed += 1

        self.report({'INFO'}, f"{removed} NOISE modifier(s) removed." if removed else "No NOISE modifiers found to remove.")
        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class SMQ_OT_UpdateNoiseModifier(bpy.types.Operator):
    bl_idname = "smq.update_noise_modifier"
    bl_label = "Update/Sync Noise Modifiers"
    bl_description = ("Synchronizes NOISE modifiers based on Loc/Rot/Scl toggles: "
                      "Adds if missing & toggle active, updates if present & toggle active, "
                      "removes if present & toggle inactive.")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        scene = context.scene

        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data on active object.")
            return {'CANCELLED'}

        updated_count = 0
        added_count = 0
        removed_count = 0

        for fc in iter_action_fcurves(obj):
            if not any(kp.select_control_point for kp in fc.keyframe_points):
                continue

            channel_type = get_channel_type(fc.data_path)
            toggle_active = (
                (channel_type == "LOC" and scene.smq_noise_apply_loc) or
                (channel_type == "ROT" and scene.smq_noise_apply_rot) or
                (channel_type == "SCL" and scene.smq_noise_apply_scl)
            )

            existing = None
            for m in fc.modifiers:
                if m.type == 'NOISE':
                    existing = m
                    break

            if toggle_active:
                if existing:
                    existing.scale = scene.smq_noise_scale
                    existing.strength = scene.smq_noise_strength
                    existing.depth = scene.smq_noise_depth
                    existing.use_restricted_range = scene.smq_noise_use_frame_range
                    existing.frame_start = scene.smq_noise_frame_start
                    existing.frame_end = scene.smq_noise_frame_end
                    existing.blend_in = scene.smq_noise_blend_in
                    existing.blend_out = scene.smq_noise_blend_out
                    existing.influence = scene.smq_noise_influence
                    updated_count += 1
                else:
                    m = fc.modifiers.new(type='NOISE')
                    m.scale = scene.smq_noise_scale
                    m.strength = scene.smq_noise_strength
                    m.depth = scene.smq_noise_depth
                    m.use_influence = True
                    m.influence = scene.smq_noise_influence
                    m.use_restricted_range = scene.smq_noise_use_frame_range
                    m.frame_start = scene.smq_noise_frame_start
                    m.frame_end = scene.smq_noise_frame_end
                    m.blend_in = scene.smq_noise_blend_in
                    m.blend_out = scene.smq_noise_blend_out
                    added_count += 1
            else:
                if existing:
                    fc.modifiers.remove(existing)
                    removed_count += 1

        parts = []
        if added_count: parts.append(f"{added_count} added")
        if updated_count: parts.append(f"{updated_count} updated")
        if removed_count: parts.append(f"{removed_count} removed")

        self.report({'INFO'}, f"Noise modifiers: {', '.join(parts)}." if parts else "No NOISE modifiers changed.")
        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


_classes = (
    SMQ_OT_SetConstantInterpolation,
    SMQ_OT_RevertToBezierInterpolation,
    SMQ_OT_AddSteppedFCurveModifier,
    SMQ_OT_RemoveSteppedFCurveModifiers,
    SMQ_OT_UpdateSteppedModifier,
    SMQ_OT_AddNoiseModifier,
    SMQ_OT_RemoveNoiseModifier,
    SMQ_OT_UpdateNoiseModifier,
)

_props = (
    # Stepped settings
    ("smq_use_frame_range", bpy.props.BoolProperty(
        name="Frame Range (Stepped)", default=False,
        description="Restrict Stepped modifier effect to a frame range"
    )),
    ("smq_frame_start", bpy.props.IntProperty(name="Start (Stepped)", default=1, min=0)),
    ("smq_frame_end", bpy.props.IntProperty(name="End (Stepped)", default=250, min=0)),
    ("smq_blend_in", bpy.props.IntProperty(name="Blend In (Stepped)", default=0, min=0)),
    ("smq_blend_out", bpy.props.IntProperty(name="Blend Out (Stepped)", default=0, min=0)),
    ("smq_influence", bpy.props.FloatProperty(name="Influence (Stepped)", default=1.0, min=0.0, max=1.0)),

    # Noise toggles
    ("smq_noise_apply_loc", bpy.props.BoolProperty(
        name="Loc", description="Target Location channels for Noise operations", default=False
    )),
    ("smq_noise_apply_rot", bpy.props.BoolProperty(
        name="Rot", description="Target Rotation channels for Noise operations", default=True
    )),
    ("smq_noise_apply_scl", bpy.props.BoolProperty(
        name="Scl", description="Target Scale channels for Noise operations", default=False
    )),

    # Noise settings
    ("smq_noise_scale", bpy.props.FloatProperty(name="Scale (Noise)", default=20.0, min=0.01, max=200.0)),
    ("smq_noise_strength", bpy.props.FloatProperty(name="Strength (Noise)", default=0.007, min=0.0, max=10.0)),
    ("smq_noise_depth", bpy.props.IntProperty(name="Detail (Noise)", default=2, min=0, max=10)),
    ("smq_noise_use_frame_range", bpy.props.BoolProperty(
        name="Frame Range (Noise)", default=False,
        description="Restrict Noise modifier effect to a frame range"
    )),
    ("smq_noise_frame_start", bpy.props.IntProperty(name="Start (Noise)", default=1, min=0)),
    ("smq_noise_frame_end", bpy.props.IntProperty(name="End (Noise)", default=250, min=0)),
    ("smq_noise_blend_in", bpy.props.IntProperty(name="Blend In (Noise)", default=0, min=0)),
    ("smq_noise_blend_out", bpy.props.IntProperty(name="Blend Out (Noise)", default=0, min=0)),
    ("smq_noise_influence", bpy.props.FloatProperty(name="Influence (Noise)", default=1.0, min=0.0, max=1.0)),
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)

    for (name, prop) in _props:
        setattr(bpy.types.Scene, name, prop)


def unregister():
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

    for (name, _) in _props:
        if hasattr(bpy.types.Scene, name):
            try:
                delattr(bpy.types.Scene, name)
            except AttributeError:
                pass