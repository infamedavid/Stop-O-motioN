import bpy

from .stop_action import SMQ_OT_QuantizeKeyframes, SMQ_OT_FillSpaces


class SMQ_PT_Panel(bpy.types.Panel):
    bl_label = "Stop - O - Motionizer"
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Stop-O-motion"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.label(text="Quantize")
        layout.prop(scene, "smq_duplicate", text="Duplicate Action")

        # Anchor mode selector (nuevo)
        layout.prop(scene, "smq_anchor_mode", text="Anchor")

        row = layout.row(align=True)
        row.prop(scene, "smq_quant_mode", expand=True)

        if scene.smq_quant_mode == 'TWOS':
            op = layout.operator(SMQ_OT_QuantizeKeyframes.bl_idname, text="Apply On Twos")
            op.interval = 2
            op.duplicate = scene.smq_duplicate
        elif scene.smq_quant_mode == 'THREES':
            op = layout.operator(SMQ_OT_QuantizeKeyframes.bl_idname, text="Apply On Threes")
            op.interval = 3
            op.duplicate = scene.smq_duplicate

        layout.separator()
        layout.label(text="Fill Spaces")

        if scene.smq_quant_mode == 'TWOS':
            op = layout.operator(SMQ_OT_FillSpaces.bl_idname, text="Fill Spaces (On Twos)")
            op.interval = 2
        elif scene.smq_quant_mode == 'THREES':
            op = layout.operator(SMQ_OT_FillSpaces.bl_idname, text="Fill Spaces (On Threes)")
            op.interval = 3

        layout.separator()
        layout.label(text="Stepped Interpolation")

        row = layout.row(align=True)
        #row.operator("smq.set_constant_interpolation", text="Curves")
        #row.operator("smq.revert_to_bezier", text="Revert")

        row = layout.row(align=True)
        row.operator("smq.add_fcurve_stepped_modifier", text="Curve Modifier")
        row.operator("smq.remove_fcurve_stepped_modifiers", text="Remove Modifier")

        layout.separator()
        layout.label(text="Stepped Modifier Settings")
        layout.prop(scene, "smq_use_frame_range")

        sub_layout_stepped = layout.column(align=True)
        sub_layout_stepped.enabled = scene.smq_use_frame_range
        row = sub_layout_stepped.row(align=True)
        row.prop(scene, "smq_frame_start")
        row.prop(scene, "smq_frame_end")

        row = sub_layout_stepped.row(align=True)
        row.prop(scene, "smq_blend_in")
        row.prop(scene, "smq_blend_out")

        layout.prop(scene, "smq_influence")
        layout.operator("smq.update_stepped_modifier", text="Update Modifier")

        layout.separator()
        layout.label(text="Noise")

        row = layout.row(align=True)
        row.operator("smq.add_noise_modifier", text="Curve Modifier")
        row.operator("smq.remove_noise_modifier", text="Remove Modifier")

        row = layout.row(align=True)
        row.prop(scene, "smq_noise_apply_loc", text="Loc", toggle=False)
        row.prop(scene, "smq_noise_apply_rot", text="Rot", toggle=False)
        row.prop(scene, "smq_noise_apply_scl", text="Scl", toggle=False)

        layout.prop(scene, "smq_noise_scale")
        layout.prop(scene, "smq_noise_strength")
        layout.prop(scene, "smq_noise_depth")

        layout.prop(scene, "smq_noise_use_frame_range")

        sub_layout_noise = layout.column(align=True)
        sub_layout_noise.enabled = scene.smq_noise_use_frame_range
        row = sub_layout_noise.row(align=True)
        row.prop(scene, "smq_noise_frame_start")
        row.prop(scene, "smq_noise_frame_end")

        row = sub_layout_noise.row(align=True)
        row.prop(scene, "smq_noise_blend_in")
        row.prop(scene, "smq_noise_blend_out")

        layout.prop(scene, "smq_noise_influence")
        layout.operator("smq.update_noise_modifier", text="Update/Sync Noise")


_classes = (SMQ_PT_Panel,)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass