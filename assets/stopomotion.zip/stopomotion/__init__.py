bl_info = {
    "name": "StopOMotion",
    "author": "infamedavid",
    "version": (1, 7),
    "blender": (5, 0, 0),
    "location": "Dope Sheet > Sidebar > Stop-O-motion",
    "description": "Turn your perfectly fluid and boring animation into a stop motion style animation",
    "category": "Animation",
}

import bpy

from . import stop_action
from . import motion_curves
from . import som_ui


def register():
    stop_action.register()
    motion_curves.register()
    som_ui.register()


def unregister():
    som_ui.unregister()
    motion_curves.unregister()
    stop_action.unregister()