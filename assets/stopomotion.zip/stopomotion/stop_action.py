import bpy


def iter_action_fcurves(obj):
    """
    Blender 5.x: Action.fcurves ya no existe; ahora están dentro de ChannelBags asociados a Action Slots.
    Retorna un iterable de FCurves SIN crear canales nuevos.
    Compatible con Blender 4.x (si existe action.fcurves).
    """
    if not obj:
        return []

    anim_data = getattr(obj, "animation_data", None)
    if not anim_data:
        return []

    action = getattr(anim_data, "action", None)
    if not action:
        return []

    # Blender 4.x
    fcurves = getattr(action, "fcurves", None)
    if fcurves is not None:
        return fcurves

    # Blender 5.x
    try:
        from bpy_extras import anim_utils
    except Exception:
        return []

    slot = getattr(anim_data, "action_slot", None)
    if slot is None:
        slots = getattr(action, "slots", None)
        if slots and len(slots) > 0:
            slot = slots[0]
            try:
                anim_data.action_slot = slot
            except Exception:
                pass
        else:
            return []

    channelbag = anim_utils.action_get_channelbag_for_slot(action, slot)
    if channelbag is None:
        ensure_fn = getattr(anim_utils, "action_ensure_channelbag_for_slot", None)
        if ensure_fn is not None:
            try:
                channelbag = ensure_fn(action, slot)
            except Exception:
                channelbag = None

    if not channelbag:
        return []

    return channelbag.fcurves


def duplicate_current_action(obj, suffix="_quantized"):
    """
    Duplica el action actual del objeto y lo reasigna.
    Devuelve el nuevo action (o None si no hay).
    """
    if not obj or not obj.animation_data or not obj.animation_data.action:
        return None

    old_action = obj.animation_data.action
    new_action = old_action.copy()
    new_action.use_fake_user = True
    new_action.name = old_action.name + suffix
    obj.animation_data.action = new_action
    return new_action


class SMQ_OT_QuantizeKeyframes(bpy.types.Operator):
    bl_idname = "smq.quantize_keyframes"
    bl_label = "Quantize Keyframes"
    bl_description = "Move selected keyframes to fall on multiples of N preserving timing"
    bl_options = {"REGISTER", "UNDO"}

    interval: bpy.props.IntProperty()
    duplicate: bpy.props.BoolProperty()

    def execute(self, context):
        obj = context.active_object
        scene = context.scene

        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No active object with animation data.")
            return {'CANCELLED'}

        if self.duplicate:
            new_action = duplicate_current_action(obj, suffix="_quantized")
            if not new_action:
                self.report({'WARNING'}, "Could not duplicate action.")
                return {'CANCELLED'}

        fcurves = list(iter_action_fcurves(obj))

        # Anchor mode:
        # - EARLIEST: primer key seleccionado (global)
        # - PLAYHEAD: frame actual
        # - PER_CHANNEL: primer key seleccionado por canal
        anchor_mode = getattr(scene, "smq_anchor_mode", "EARLIEST")

        if anchor_mode == "PER_CHANNEL":
            # Cuantiza cada canal con su propio anchor (primer key seleccionado en ese canal)
            any_selected = False

            for fc in fcurves:
                selected = [kp for kp in fc.keyframe_points if kp.select_control_point]
                if not selected:
                    continue

                any_selected = True
                anchor = min(kp.co[0] for kp in selected)

                for kp in selected:
                    old_frame = kp.co[0]
                    new_frame = anchor + round((old_frame - anchor) / self.interval) * self.interval
                    kp.co[0] = round(new_frame)
                    kp.select_control_point = False

            if not any_selected:
                self.report({'WARNING'}, "No selected keyframes found.")
                return {'CANCELLED'}

        else:
            # Anchor global (EARLIEST o PLAYHEAD)
            selected_pairs = []
            for fc in fcurves:
                for kp in fc.keyframe_points:
                    if kp.select_control_point:
                        selected_pairs.append((fc, kp))

            if not selected_pairs:
                self.report({'WARNING'}, "No selected keyframes found.")
                return {'CANCELLED'}

            if anchor_mode == "PLAYHEAD":
                anchor = float(scene.frame_current)
            else:
                # EARLIEST (default)
                anchor = min(kp.co[0] for _, kp in selected_pairs)

            for _, kp in selected_pairs:
                old_frame = kp.co[0]
                new_frame = anchor + round((old_frame - anchor) / self.interval) * self.interval
                kp.co[0] = round(new_frame)
                kp.select_control_point = False

        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


class SMQ_OT_FillSpaces(bpy.types.Operator):
    bl_idname = "smq.fill_spaces"
    bl_label = "Fill Spaces"
    bl_description = "Add keyframes in between selected keyframes using current quantization interval"
    bl_options = {"REGISTER", "UNDO"}

    interval: bpy.props.IntProperty()

    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No active object with animation data.")
            return {'CANCELLED'}

        inserted = 0
        for fc in iter_action_fcurves(obj):
            keyframes = [kp.co[0] for kp in fc.keyframe_points if kp.select_control_point]
            if len(keyframes) < 2:
                continue

            keyframes = sorted(set(round(k) for k in keyframes))

            for i in range(len(keyframes) - 1):
                start = keyframes[i]
                end = keyframes[i + 1]
                frame = start + self.interval

                while frame < end:
                    exists = any(abs(kp_existing.co[0] - frame) < 0.001 for kp_existing in fc.keyframe_points)
                    if not exists:
                        value = fc.evaluate(frame)
                        fc.keyframe_points.insert(frame, value, options={'FAST'})
                        inserted += 1
                    frame += self.interval

        if inserted == 0:
            self.report({'INFO'}, "No intermediate frames to insert.")
        else:
            self.report({'INFO'}, f"{inserted} keyframes inserted.")

        if hasattr(context, 'area') and context.area:
            context.area.tag_redraw()
        return {'FINISHED'}


_classes = (
    SMQ_OT_QuantizeKeyframes,
    SMQ_OT_FillSpaces,
)

_props = (
    ("smq_duplicate", bpy.props.BoolProperty(
        name="Duplicate Action",
        description="Duplicate current action before quantizing",
        default=True
    )),
    ("smq_quant_mode", bpy.props.EnumProperty(
        name="Quantization Mode",
        description="Choose quantization interval",
        items=[
            ('TWOS', 'On Twos', "Quantize to every 2 frames"),
            ('THREES', 'On Threes', "Quantize to every 3 frames"),
        ],
        default='TWOS'
    )),
    ("smq_anchor_mode", bpy.props.EnumProperty(
        name="Anchor",
        description="Which frame is used as the anchor for quantization",
        items=[
            ('EARLIEST', 'Earliest Selected', "Use the earliest selected keyframe as the anchor (global)"),
            ('PLAYHEAD', 'Playhead', "Use the current frame as the anchor (global)"),
            ('PER_CHANNEL', 'Per Channel', "Use the earliest selected keyframe in each F-Curve as the anchor"),
        ],
        default='EARLIEST'
    )),
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)

    for (name, prop) in _props:
        setattr(bpy.types.Scene, name, prop)


def unregister():
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

    for (name, _) in _props:
        if hasattr(bpy.types.Scene, name):
            try:
                delattr(bpy.types.Scene, name)
            except AttributeError:
                pass